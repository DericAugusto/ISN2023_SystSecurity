docker kill factory_host
docker kill openplc_host
docker kill scadabr_host
docker network rm scada-network
