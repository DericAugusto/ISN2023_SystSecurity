docker build -t factory -f dockerfiles/factory.docker dockerfiles
docker build -t openplc -f dockerfiles/openplc.docker dockerfiles
docker build -t scadabr -f dockerfiles/scadabr.docker dockerfiles

